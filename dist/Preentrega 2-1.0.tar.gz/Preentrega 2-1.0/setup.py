from setuptools import setup

setup(
    name = "Preentrega 2",
    version = "1.0",
    description = "Preentrega Numero 2 - CoderHouse.",
    author = "Matias Kehler",
    author_email = "Matias.Kehler@gmail.com",
    packages = ["packages"]
)